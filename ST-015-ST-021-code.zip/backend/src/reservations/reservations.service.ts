import * as crypto from 'node:crypto';
import {
  BadRequestException,
  ConflictException,
  ForbiddenException,
  GoneException,
  Injectable,
  NotFoundException,
} from '@nestjs/common';
import {
  Prisma,
  ReservationSource,
  ReservationStatus,
} from '@prisma/client';
import { DEFAULT_TX_OPTIONS, runWithPgRetry } from '../common/pg-tx.util';
import { PrismaService } from '../prisma/prisma.service';
import { WaitlistService } from '../waitlist/waitlist.service';
import type {
  CreateReservationDto,
  ReservationMutationResponse,
  ReservationResponse,
} from './dto/reservations.dto';

const HOLD_MINUTES = 10;
const IDEMPOTENCY_RE = /^[A-Za-z0-9._:-]{1,80}$/;

@Injectable()
export class ReservationsService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly waitlistService: WaitlistService,
  ) {}

  async create(
    userId: string,
    dto: CreateReservationDto,
    idempotencyKey?: string,
  ): Promise<ReservationResponse> {
    const key = this.requireIdempotencyKey(idempotencyKey);
    const endpoint = 'POST /api/reservations';
    const requestId = `${userId}:${key}`;
    const requestHash = this.hashRequest(endpoint, dto);

    return runWithPgRetry(
      () =>
        this.prisma.$transaction(
          async (tx) => {
            const replay = await this.getReplay<ReservationResponse>(
              tx,
              requestId,
              endpoint,
              requestHash,
            );
            if (replay) return replay;

            await this.lockIdempotencyKey(tx, requestId);

            const afterLockReplay = await this.getReplay<ReservationResponse>(
              tx,
              requestId,
              endpoint,
              requestHash,
            );
            if (afterLockReplay) return afterLockReplay;

            const [event] = await tx.$queryRaw<Array<{
              id: string;
              slug: string;
              title: string;
              category: string;
              venue: string;
              address: string;
              city: string;
              poster: string;
              priceVnd: number;
              startsAt: Date;
              salesCloseAt: Date;
              capacity: number;
              reservedCount: number;
              soldCount: number;
            }>>`
              SELECT
                "id"::text AS "id",
                "slug", "title", "category", "venue", "address", "city", "poster",
                "price_vnd" AS "priceVnd",
                "starts_at" AS "startsAt",
                "sales_close_at" AS "salesCloseAt",
                "capacity",
                "reserved_count" AS "reservedCount",
                "sold_count" AS "soldCount"
              FROM "events"
              WHERE "id" = CAST(${dto.eventId} AS uuid)
              FOR UPDATE
            `;

            if (!event) throw new NotFoundException('Không tìm thấy sự kiện.');

            const [{ dbNow }] = await tx.$queryRaw<Array<{ dbNow: Date }>>`
              SELECT clock_timestamp() AS "dbNow"
            `;

            if (dbNow >= event.salesCloseAt) {
              throw new ConflictException('Sự kiện đã đóng bán vé.');
            }
            if (dbNow >= event.startsAt) {
              throw new ConflictException('Sự kiện đã bắt đầu.');
            }
            if (event.soldCount + event.reservedCount >= event.capacity) {
              throw new ConflictException('Sự kiện đã hết vé.');
            }

            const active = await tx.reservation.findFirst({
              where: {
                eventId: dto.eventId,
                userId,
                status: { in: [ReservationStatus.HOLD, ReservationStatus.CONFIRMED] },
              },
              select: { id: true, status: true },
            });
            if (active) {
              throw new ConflictException(
                active.status === ReservationStatus.CONFIRMED
                  ? 'Bạn đã có vé cho sự kiện này.'
                  : 'Bạn đang có một lượt giữ vé cho sự kiện này.',
              );
            }

            const expiresAt = new Date(dbNow.getTime() + HOLD_MINUTES * 60_000);
            const reservation = await tx.reservation.create({
              data: {
                eventId: dto.eventId,
                userId,
                source: ReservationSource.DIRECT,
                status: ReservationStatus.HOLD,
                priceVnd: event.priceVnd,
                expiresAt,
              },
            });

            await tx.event.update({
              where: { id: dto.eventId },
              data: { reservedCount: { increment: 1 } },
            });

            const response = this.toResponse({
              ...reservation,
              event,
            });

            await this.saveIdempotency(
              tx,
              requestId,
              userId,
              endpoint,
              requestHash,
              HttpStatusLike.CREATED,
              response,
            );
            return response;
          },
          DEFAULT_TX_OPTIONS,
        ),
      3,
    );
  }

  async getMine(userId: string): Promise<ReservationResponse[]> {
    const rows = await this.prisma.reservation.findMany({
      where: { userId },
      orderBy: { createdAt: 'desc' },
      include: {
        event: {
          select: {
            id: true,
            slug: true,
            title: true,
            category: true,
            venue: true,
            address: true,
            city: true,
            poster: true,
            startsAt: true,
            priceVnd: true,
          },
        },
      },
    });
    return rows.map((row) => this.toResponse(row));
  }

  async getOne(userId: string, id: string): Promise<ReservationResponse> {
    const row = await this.prisma.reservation.findUnique({
      where: { id },
      include: {
        event: {
          select: {
            id: true,
            slug: true,
            title: true,
            category: true,
            venue: true,
            address: true,
            city: true,
            poster: true,
            startsAt: true,
            priceVnd: true,
          },
        },
      },
    });
    if (!row) throw new NotFoundException('Không tìm thấy lượt giữ chỗ.');
    if (row.userId !== userId) {
      throw new ForbiddenException('Bạn không có quyền xem lượt giữ chỗ này.');
    }
    return this.toResponse(row);
  }

  async confirm(
    userId: string,
    reservationId: string,
    idempotencyKey?: string,
  ): Promise<ReservationMutationResponse> {
    const key = this.requireIdempotencyKey(idempotencyKey);
    const endpoint = `POST /api/reservations/${reservationId}/confirm`;
    const requestId = `${userId}:${key}`;
    const requestHash = this.hashRequest(endpoint, { reservationId });

    return runWithPgRetry(
      () =>
        this.prisma.$transaction(
          async (tx) => {
            await this.lockIdempotencyKey(tx, requestId);
            const replay = await this.getReplay<ReservationMutationResponse>(
              tx,
              requestId,
              endpoint,
              requestHash,
            );
            if (replay) return replay;

            const [reservation] = await tx.$queryRaw<Array<{
              id: string;
              eventId: string;
              userId: string;
              source: ReservationSource;
              status: ReservationStatus;
              priceVnd: number;
              expiresAt: Date;
            }>>`
              SELECT
                "id"::text AS "id",
                "event_id"::text AS "eventId",
                "user_id"::text AS "userId",
                "source"::text AS "source",
                "status"::text AS "status",
                "price_vnd" AS "priceVnd",
                "expires_at" AS "expiresAt"
              FROM "reservations"
              WHERE "id" = CAST(${reservationId} AS uuid)
              FOR UPDATE
            `;
            if (!reservation) throw new NotFoundException('Không tìm thấy lượt giữ chỗ.');
            if (reservation.userId !== userId) {
              throw new ForbiddenException('Bạn không có quyền xác nhận lượt giữ chỗ này.');
            }
            if (reservation.source === ReservationSource.WAITLIST_OFFER) {
              throw new ConflictException('Reservation thuộc Offer phải được xử lý qua API Offer.');
            }

            const [event] = await tx.$queryRaw<Array<{
              id: string;
              title: string;
            }>>`
              SELECT "id"::text AS "id", "title"
              FROM "events"
              WHERE "id" = CAST(${reservation.eventId} AS uuid)
              FOR UPDATE
            `;
            if (!event) throw new NotFoundException('Sự kiện không tồn tại.');

            if (reservation.status === ReservationStatus.CONFIRMED) {
              const current = await this.prismaReservationInTx(tx, reservationId);
              const response: ReservationMutationResponse = {
                success: true,
                message: 'Vé đã được xác nhận trước đó.',
                reservation: this.toResponse(current),
                ticketCode: current.ticketCode ?? undefined,
                confirmedAt: current.confirmedAt?.toISOString(),
                receiptContent: (current.receiptContent as Record<string, unknown> | null) ?? undefined,
              };
              await this.saveIdempotency(tx, requestId, userId, endpoint, requestHash, 200, response);
              return response;
            }

            if (reservation.status !== ReservationStatus.HOLD) {
              throw new ConflictException('Reservation không còn ở trạng thái HOLD.');
            }

            const [{ dbNow }] = await tx.$queryRaw<Array<{ dbNow: Date }>>`
              SELECT clock_timestamp() AS "dbNow"
            `;
            if (dbNow >= reservation.expiresAt) {
              throw new GoneException('Lượt giữ vé đã hết hạn. Vui lòng đặt lại.');
            }

            const ticketCode = `TKT-${crypto.randomBytes(4).toString('hex').toUpperCase()}-${dbNow.getTime().toString(36).toUpperCase()}`;
            const receiptContent: Prisma.InputJsonObject = {
              ticketCode,
              reservationId,
              eventId: reservation.eventId,
              eventTitle: event.title,
              userId,
              priceVnd: reservation.priceVnd,
              confirmedAt: dbNow.toISOString(),
            };

            await tx.reservation.update({
              where: { id: reservationId },
              data: {
                status: ReservationStatus.CONFIRMED,
                ticketCode,
                confirmedAt: dbNow,
                receiptContent,
              },
            });
            await tx.event.update({
              where: { id: reservation.eventId },
              data: {
                reservedCount: { decrement: 1 },
                soldCount: { increment: 1 },
              },
            });

            const current = await this.prismaReservationInTx(tx, reservationId);
            const response: ReservationMutationResponse = {
              success: true,
              message: 'Xác nhận đặt vé thành công.',
              reservation: this.toResponse(current),
              ticketCode,
              confirmedAt: dbNow.toISOString(),
              receiptContent: receiptContent as Record<string, unknown>,
            };
            await this.saveIdempotency(tx, requestId, userId, endpoint, requestHash, 200, response);
            return response;
          },
          DEFAULT_TX_OPTIONS,
        ),
      3,
    );
  }

  async cancel(
    userId: string,
    reservationId: string,
    idempotencyKey?: string,
  ): Promise<ReservationMutationResponse> {
    const key = this.requireIdempotencyKey(idempotencyKey);
    const endpoint = `DELETE /api/reservations/${reservationId}`;
    const requestId = `${userId}:${key}`;
    const requestHash = this.hashRequest(endpoint, { reservationId });

    return runWithPgRetry(
      () =>
        this.prisma.$transaction(
          async (tx) => {
            await this.lockIdempotencyKey(tx, requestId);
            const replay = await this.getReplay<ReservationMutationResponse>(
              tx,
              requestId,
              endpoint,
              requestHash,
            );
            if (replay) return replay;

            const [reservation] = await tx.$queryRaw<Array<{
              id: string;
              eventId: string;
              userId: string;
              source: ReservationSource;
              status: ReservationStatus;
            }>>`
              SELECT
                "id"::text AS "id",
                "event_id"::text AS "eventId",
                "user_id"::text AS "userId",
                "source"::text AS "source",
                "status"::text AS "status"
              FROM "reservations"
              WHERE "id" = CAST(${reservationId} AS uuid)
              FOR UPDATE
            `;
            if (!reservation) throw new NotFoundException('Không tìm thấy lượt giữ chỗ.');
            if (reservation.userId !== userId) {
              throw new ForbiddenException('Bạn không có quyền hủy lượt giữ chỗ này.');
            }
            if (reservation.source === ReservationSource.WAITLIST_OFFER) {
              throw new ConflictException('Reservation thuộc Offer phải được xử lý qua API Offer.');
            }

            const [event] = await tx.$queryRaw<Array<{ id: string }>>`
              SELECT "id"::text AS "id"
              FROM "events"
              WHERE "id" = CAST(${reservation.eventId} AS uuid)
              FOR UPDATE
            `;
            if (!event) throw new NotFoundException('Sự kiện không tồn tại.');

            if (
              reservation.status === ReservationStatus.CANCELLED ||
              reservation.status === ReservationStatus.EXPIRED
            ) {
              const current = await this.prismaReservationInTx(tx, reservationId);
              const response: ReservationMutationResponse = {
                success: true,
                message: 'Reservation đã được hủy/hết hạn trước đó.',
                reservation: this.toResponse(current),
                promotedNext: false,
              };
              await this.saveIdempotency(tx, requestId, userId, endpoint, requestHash, 200, response);
              return response;
            }

            if (
              reservation.status !== ReservationStatus.HOLD &&
              reservation.status !== ReservationStatus.CONFIRMED
            ) {
              throw new ConflictException('Trạng thái reservation không thể hủy.');
            }

            const [{ dbNow }] = await tx.$queryRaw<Array<{ dbNow: Date }>>`
              SELECT clock_timestamp() AS "dbNow"
            `;

            const wasHold = reservation.status === ReservationStatus.HOLD;
            await tx.reservation.update({
              where: { id: reservationId },
              data: { status: ReservationStatus.CANCELLED, cancelledAt: dbNow },
            });
            await tx.event.update({
              where: { id: reservation.eventId },
              data: wasHold
                ? { reservedCount: { decrement: 1 } }
                : { soldCount: { decrement: 1 } },
            });

            const promoted = await this.waitlistService.promoteNextWaitlist(
              reservation.eventId,
              tx,
            );

            const current = await this.prismaReservationInTx(tx, reservationId);
            const response: ReservationMutationResponse = {
              success: true,
              message: 'Đã hủy reservation và giải phóng chỗ.',
              reservation: this.toResponse(current),
              promotedNext: promoted.promoted,
              ...(promoted.promoted ? { nextOfferId: promoted.offerId } : {}),
            };
            await this.saveIdempotency(tx, requestId, userId, endpoint, requestHash, 200, response);
            return response;
          },
          DEFAULT_TX_OPTIONS,
        ),
      3,
    );
  }

  private requireIdempotencyKey(key?: string): string {
    if (!key || !IDEMPOTENCY_RE.test(key)) {
      throw new BadRequestException(
        'Header Idempotency-Key là bắt buộc, tối đa 80 ký tự và chỉ gồm chữ, số, . _ : -.',
      );
    }
    return key;
  }

  private hashRequest(endpoint: string, body: unknown): string {
    return crypto
      .createHash('sha256')
      .update(`${endpoint}\n${stableStringify(body)}`)
      .digest('hex');
  }

  private async lockIdempotencyKey(
    tx: Prisma.TransactionClient,
    requestId: string,
  ): Promise<void> {
    await tx.$executeRaw`
      SELECT pg_advisory_xact_lock(hashtextextended(${requestId}, 0))
    `;
  }

  private async getReplay<T>(
    tx: Prisma.TransactionClient,
    requestId: string,
    endpoint: string,
    requestHash: string,
  ): Promise<T | null> {
    const record = await tx.idempotencyRecord.findUnique({ where: { requestId } });
    if (!record) return null;
    if (record.endpoint !== endpoint || record.requestHash !== requestHash) {
      throw new ConflictException(
        'Idempotency-Key đã được sử dụng cho endpoint hoặc payload khác.',
      );
    }
    return record.responseBody as T;
  }

  private async saveIdempotency(
    tx: Prisma.TransactionClient,
    requestId: string,
    userId: string,
    endpoint: string,
    requestHash: string,
    responseStatus: number,
    responseBody: unknown,
  ): Promise<void> {
    await tx.idempotencyRecord.create({
      data: {
        requestId,
        userId,
        endpoint,
        requestHash,
        responseStatus,
        responseBody: responseBody as Prisma.InputJsonValue,
      },
    });
  }

  private async prismaReservationInTx(
    tx: Prisma.TransactionClient,
    id: string,
  ) {
    return tx.reservation.findUniqueOrThrow({
      where: { id },
      include: {
        event: {
          select: {
            id: true,
            slug: true,
            title: true,
            category: true,
            venue: true,
            address: true,
            city: true,
            poster: true,
            startsAt: true,
            priceVnd: true,
          },
        },
      },
    });
  }

  private toResponse(row: any): ReservationResponse {
    return {
      id: row.id,
      eventId: row.eventId,
      userId: row.userId,
      source: row.source,
      status: row.status,
      priceVnd: row.priceVnd,
      expiresAt: new Date(row.expiresAt).toISOString(),
      ticketCode: row.ticketCode ?? null,
      receiptContent: row.receiptContent ?? null,
      confirmedAt: row.confirmedAt ? new Date(row.confirmedAt).toISOString() : null,
      cancelledAt: row.cancelledAt ? new Date(row.cancelledAt).toISOString() : null,
      createdAt: new Date(row.createdAt).toISOString(),
      event: row.event
        ? {
            id: row.event.id,
            slug: row.event.slug,
            title: row.event.title,
            category: row.event.category,
            venue: row.event.venue,
            address: row.event.address,
            city: row.event.city,
            poster: row.event.poster,
            startsAt: new Date(row.event.startsAt).toISOString(),
            priceVnd: row.event.priceVnd,
          }
        : undefined,
    };
  }
}

const HttpStatusLike = {
  CREATED: 201,
} as const;

function stableStringify(value: unknown): string {
  if (value === null || typeof value !== 'object') return JSON.stringify(value);
  if (Array.isArray(value)) return `[${value.map(stableStringify).join(',')}]`;
  const obj = value as Record<string, unknown>;
  return `{${Object.keys(obj).sort().map((k) => `${JSON.stringify(k)}:${stableStringify(obj[k])}`).join(',')}}`;
}
