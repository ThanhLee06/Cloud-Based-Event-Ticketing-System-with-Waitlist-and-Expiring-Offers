import { IsInt, IsNotEmpty, IsUUID, Max, Min } from 'class-validator';

export class CreateReservationDto {
  @IsNotEmpty({ message: 'Vui lòng cung cấp eventId.' })
  @IsUUID('all', { message: 'eventId phải là UUID hợp lệ.' })
  eventId!: string;

  @IsInt({ message: 'quantity phải là số nguyên.' })
  @Min(1, { message: 'quantity tối thiểu là 1.' })
  @Max(1, { message: 'Mỗi lượt chỉ được giữ 1 vé.' })
  quantity!: number;
}

export interface ReservationResponse {
  id: string;
  eventId: string;
  userId: string;
  source: 'DIRECT' | 'WAITLIST_OFFER';
  status: 'HOLD' | 'CONFIRMED' | 'CANCELLED' | 'EXPIRED';
  priceVnd: number;
  expiresAt: string;
  ticketCode: string | null;
  receiptContent: unknown;
  confirmedAt: string | null;
  cancelledAt: string | null;
  createdAt: string;
  event?: {
    id: string;
    slug: string;
    title: string;
    category: string;
    venue: string;
    address: string;
    city: string;
    poster: string;
    startsAt: string;
    priceVnd: number;
  };
}

export interface ReservationMutationResponse {
  success: boolean;
  message: string;
  reservation: ReservationResponse;
  ticketCode?: string;
  confirmedAt?: string;
  receiptContent?: Record<string, unknown>;
  promotedNext?: boolean;
  nextOfferId?: string;
}
