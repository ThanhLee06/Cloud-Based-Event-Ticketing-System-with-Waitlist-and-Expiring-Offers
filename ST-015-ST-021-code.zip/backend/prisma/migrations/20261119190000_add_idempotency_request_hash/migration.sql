-- ST-015 / ST-017: SHA-256 fingerprint of the idempotent request.
ALTER TABLE "idempotency_records"
ADD COLUMN "request_hash" VARCHAR(64);

-- Existing rows, if any, cannot be replayed safely without a fingerprint.
-- Use a deterministic placeholder so the new NOT NULL constraint can be applied.
UPDATE "idempotency_records"
SET "request_hash" = repeat('0', 64)
WHERE "request_hash" IS NULL;

ALTER TABLE "idempotency_records"
ALTER COLUMN "request_hash" SET NOT NULL;

CREATE INDEX "idempotency_records_user_id_endpoint_idx"
ON "idempotency_records"("user_id", "endpoint");
