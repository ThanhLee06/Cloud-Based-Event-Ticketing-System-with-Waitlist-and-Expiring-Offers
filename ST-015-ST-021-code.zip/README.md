# ST-015 → ST-021 — Code implementation

This package contains the code for the seven tasks based on the uploaded project specification and its existing NestJS/Prisma/Next.js structure.

## ST-015
- `backend/prisma/schema.prisma`: Reservation + IdempotencyRecord with `requestHash`.
- `backend/prisma/migrations/20261119190000_add_idempotency_request_hash/migration.sql`

## ST-016 → ST-020
- `backend/src/reservations/dto/reservations.dto.ts`
- `backend/src/reservations/reservations.controller.ts`
- `backend/src/reservations/reservations.service.ts`
- `backend/src/reservations/reservations.module.ts`
- `backend/src/app.module.ts`

Implemented:
- `POST /api/reservations`
- event row locking with `SELECT ... FOR UPDATE`
- 10-minute HOLD
- capacity check
- ownership guard
- confirmation to ticket + JSON receipt
- cancellation and exactly-once counter decrement
- FIFO promotion through existing `WaitlistService`
- idempotency key validation
- SHA-256 request fingerprint
- PostgreSQL advisory transaction lock for concurrent duplicate requests
- replay of the original response
- HTTP 409 for same key + different endpoint/payload
- WAITLIST_OFFER reservations are rejected by Reservations API and must go through Offer API.

## ST-021
- `frontend/lib/api/reservations.ts`
- `frontend/app/events/[slug]/page.tsx`
- `frontend/app/checkout/[reservationId]/page.tsx`
- `frontend/app/my-tickets/page.tsx`

The three frontend screens use the real Reservations API instead of the Mock Store for backend-backed events.

## Apply
Copy the files over the matching paths in the original project, then:

```bash
cd backend
pnpm install
pnpm prisma:generate
pnpm prisma:deploy
pnpm typecheck
pnpm start:dev
```

Frontend:

```bash
cd frontend
pnpm install
pnpm typecheck
pnpm dev
```

If the database has never had the previous development migrations, use `pnpm prisma:migrate` during local development.

## Important
The implementation follows the uploaded `ST-015-ST-021.md` specification. It assumes the existing `WaitlistService`, `OffersModule`, JWT guard, and PostgreSQL schema from the uploaded project remain in place.
