import { api, getApiErrorMessage, requestIdempotent, type IdempotentOptions } from './client';

export type ReservationStatus = 'HOLD' | 'CONFIRMED' | 'CANCELLED' | 'EXPIRED';
export type ReservationSource = 'DIRECT' | 'WAITLIST_OFFER';

export interface ReservationEvent {
  id: string;
  slug: string;
  title: string;
  category: string;
  venue: string;
  address: string;
  city: string;
  poster: string;
  startsAt: string;
  priceVnd: number;
}

export interface Reservation {
  id: string;
  eventId: string;
  userId: string;
  source: ReservationSource;
  status: ReservationStatus;
  priceVnd: number;
  expiresAt: string;
  ticketCode: string | null;
  receiptContent: Record<string, unknown> | null;
  confirmedAt: string | null;
  cancelledAt: string | null;
  createdAt: string;
  event?: ReservationEvent;
}

export interface ReservationMutationResponse {
  success: boolean;
  message: string;
  reservation: Reservation;
  ticketCode?: string;
  confirmedAt?: string;
  receiptContent?: Record<string, unknown>;
  promotedNext?: boolean;
  nextOfferId?: string;
}

const normalizeOptions = (options?: IdempotentOptions): IdempotentOptions => ({
  retries: 2,
  ...options,
});

export const createReservation = async (
  eventId: string,
  options?: IdempotentOptions,
): Promise<Reservation> => {
  const { data } = await requestIdempotent<Reservation>(
    'post',
    '/reservations',
    { eventId, quantity: 1 },
    normalizeOptions(options),
  );
  return data;
};

export const getMyReservations = async (): Promise<Reservation[]> => {
  const { data } = await api.get<Reservation[]>('/reservations/me');
  return data;
};

export const getReservation = async (id: string): Promise<Reservation> => {
  const { data } = await api.get<Reservation>(`/reservations/${id}`);
  return data;
};

export const confirmReservation = async (
  id: string,
  options?: IdempotentOptions,
): Promise<ReservationMutationResponse> => {
  const { data } = await requestIdempotent<ReservationMutationResponse>(
    'post',
    `/reservations/${id}/confirm`,
    undefined,
    normalizeOptions(options),
  );
  return data;
};

export const cancelReservation = async (
  id: string,
  options?: IdempotentOptions,
): Promise<ReservationMutationResponse> => {
  const { data } = await requestIdempotent<ReservationMutationResponse>(
    'delete',
    `/reservations/${id}`,
    undefined,
    normalizeOptions(options),
  );
  return data;
};

export { getApiErrorMessage };
