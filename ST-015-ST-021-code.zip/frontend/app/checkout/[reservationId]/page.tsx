'use client';

import React, { useEffect, useState } from 'react';
import { useParams, useRouter } from 'next/navigation';
import Link from 'next/link';
import { useAuth, loginRedirectPath } from '@lib/auth/AuthProvider';
import {
  cancelReservation,
  confirmReservation,
  getReservation,
  type Reservation,
} from '@lib/api/reservations';
import { getApiErrorMessage } from '@lib/api/client';
import { formatVND, formatDateVN } from '@lib/utils/format';
import Countdown from '@components/Countdown/Countdown';
import ConfirmDialog from '@components/Modal/ConfirmDialog';
import {
  Calendar,
  MapPin,
  CheckCircle2,
  AlertTriangle,
  ArrowLeft,
  ShieldAlert,
  Info,
  XCircle,
  AlertCircle,
} from 'lucide-react';

const NoticeState: React.FC<{
  Icon: typeof AlertCircle;
  danger?: boolean;
  title: string;
  desc: React.ReactNode;
  href: string;
  cta: string;
}> = ({ Icon, danger, title, desc, href, cta }) => (
  <div className='ef-container-sm'>
    <div className={`ef-icon-circle ${danger ? 'ef-icon-circle-danger' : 'ef-icon-circle-neutral'}`}>
      <Icon size={30} />
    </div>
    <h1 style={{ fontSize: '1.4rem', fontWeight: 700, marginBottom: 8 }}>{title}</h1>
    <p style={{ color: 'var(--text-muted)', fontSize: '0.92rem', marginBottom: 24, lineHeight: 1.5 }}>
      {desc}
    </p>
    <Link href={href} className='ef-btn ef-btn-primary'>
      <ArrowLeft size={16} />
      <span>{cta}</span>
    </Link>
  </div>
);

const CheckoutPage: React.FC = () => {
  const params = useParams();
  const router = useRouter();
  const reservationId = params?.reservationId as string;
  const { status, loggedOutByUser } = useAuth();

  const [reservation, setReservation] = useState<Reservation | null>(null);
  const [loading, setLoading] = useState(true);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showCancelDialog, setShowCancelDialog] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  useEffect(() => {
    if (status === 'loading' || !reservationId) return;
    if (status === 'anonymous') {
      router.replace(loginRedirectPath(`/checkout/${reservationId}`, loggedOutByUser));
      return;
    }
    let active = true;
    setLoading(true);
    getReservation(reservationId)
      .then((data) => {
        if (active) setReservation(data);
      })
      .catch((err) => {
        if (active) setErrorMessage(getApiErrorMessage(err, 'Không thể tải lượt giữ vé.'));
      })
      .finally(() => active && setLoading(false));
    return () => {
      active = false;
    };
  }, [reservationId, status, router, loggedOutByUser]);

  if (loading) return <div className='ef-loading'>Đang tải thông tin đơn đặt vé...</div>;

  if (!reservation || !reservation.event) {
    return (
      <NoticeState
        Icon={AlertCircle}
        danger
        title='Không tìm thấy lượt giữ vé'
        desc={errorMessage ?? 'Lượt giữ chỗ không tồn tại hoặc bạn không có quyền truy cập.'}
        href='/'
        cta='Khám phá sự kiện khác'
      />
    );
  }

  const event = reservation.event;
  const isExpired = reservation.status === 'EXPIRED';
  const isAlreadyConfirmed = reservation.status === 'CONFIRMED';
  const isCancelled = reservation.status === 'CANCELLED';
  const isTerminal = isExpired || isAlreadyConfirmed || isCancelled;

  const handleConfirm = async () => {
    if (isTerminal) return;
    setIsSubmitting(true);
    setErrorMessage(null);
    try {
      const result = await confirmReservation(reservation.id);
      setReservation(result.reservation);
    } catch (err) {
      setErrorMessage(getApiErrorMessage(err, 'Xác nhận đặt vé thất bại.'));
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleCancel = async () => {
    setIsSubmitting(true);
    setErrorMessage(null);
    try {
      const result = await cancelReservation(reservation.id);
      setReservation(result.reservation);
      setShowCancelDialog(false);
    } catch (err) {
      setErrorMessage(getApiErrorMessage(err, 'Không thể hủy giữ vé.'));
      setShowCancelDialog(false);
    } finally {
      setIsSubmitting(false);
    }
  };

  const priceDisplay = reservation.priceVnd === 0 ? 'Miễn phí' : formatVND(reservation.priceVnd);

  return (
    <div style={{ maxWidth: 720, margin: '24px auto 60px', padding: '0 16px' }}>
      <nav style={{ display: 'flex', gap: 8, fontSize: '0.84rem', color: 'var(--text-muted)', marginBottom: 20 }}>
        <Link href='/'>Khám phá</Link><span>/</span>
        <Link href={`/events/${event.slug}`}>{event.title}</Link><span>/</span>
        <span style={{ color: 'var(--text)', fontWeight: 600 }}>Xác nhận vé</span>
      </nav>

      <div className='ef-card-lg'>
        <div style={{ marginBottom: 20 }}>
          <h1 style={{ fontSize: '1.45rem', fontWeight: 700, marginBottom: 4 }}>
            Xác nhận thông tin đặt vé
          </h1>
          <div style={{ fontSize: '0.82rem', color: 'var(--text-muted)' }}>
            Mã giữ chỗ: <strong>{reservation.id}</strong>
          </div>
        </div>

        {!isTerminal && <Countdown expiresAt={reservation.expiresAt} label='Vé đang được giữ riêng cho bạn trong:' />}

        {isExpired && (
          <div className='ef-badge-danger' style={{ padding: 14, borderRadius: 10, margin: '20px 0', display: 'flex', gap: 12 }}>
            <AlertTriangle size={20} />
            <div><strong>Lượt giữ vé đã hết hạn.</strong><div>Vui lòng quay lại sự kiện và đặt lại.</div></div>
          </div>
        )}

        {isCancelled && (
          <div className='ef-badge-neutral' style={{ padding: 14, borderRadius: 10, margin: '20px 0', display: 'flex', gap: 12 }}>
            <XCircle size={20} />
            <div><strong>Lượt giữ vé đã được hủy.</strong><div>Chỗ đã được trả lại kho vé.</div></div>
          </div>
        )}

        {isAlreadyConfirmed && (
          <div className='ef-badge-success' style={{ padding: 16, borderRadius: 10, margin: '20px 0', display: 'flex', gap: 12 }}>
            <CheckCircle2 size={22} />
            <div><strong>Đặt vé thành công!</strong><div>Mã vé: <strong>{reservation.ticketCode}</strong></div></div>
          </div>
        )}

        {errorMessage && (
          <div className='ef-badge-danger' style={{ padding: '12px 16px', borderRadius: 8, margin: '20px 0' }}>
            {errorMessage}
          </div>
        )}

        <div style={{ display: 'flex', gap: 16, padding: 16, backgroundColor: 'var(--canvas)', borderRadius: 12, border: '1px solid var(--border)', margin: '20px 0', alignItems: 'center' }}>
          <img src={event.poster} alt={event.title} style={{ width: 80, height: 80, borderRadius: 8, objectFit: 'cover' }} />
          <div>
            <div style={{ fontSize: '0.78rem', color: 'var(--text-muted)', fontWeight: 600 }}>{event.category}</div>
            <h2 style={{ fontSize: '1.05rem', fontWeight: 700, marginBottom: 6 }}>{event.title}</h2>
            <div style={{ display: 'flex', gap: 12, fontSize: '0.82rem', color: 'var(--text-muted)', flexWrap: 'wrap' }}>
              <span><Calendar size={14} style={{ verticalAlign: 'middle' }} /> {formatDateVN(event.startsAt)}</span>
              <span><MapPin size={14} style={{ verticalAlign: 'middle' }} /> {event.venue}, {event.city}</span>
            </div>
          </div>
        </div>

        <div style={{ borderTop: '1px solid var(--border)', borderBottom: '1px solid var(--border)', padding: '16px 0', marginBottom: 24 }}>
          <div style={{ display: 'flex', justifyContent: 'space-between' }}>
            <span>1 × Vé tham dự tiêu chuẩn</span><strong>{priceDisplay}</strong>
          </div>
          <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: 10 }}>
            <span>Phí xử lý giao dịch</span><span>0 ₫</span>
          </div>
          <div style={{ display: 'flex', justifyContent: 'space-between', paddingTop: 12, marginTop: 12, borderTop: '1px dashed var(--border)' }}>
            <strong>Tổng thanh toán</strong><strong>{priceDisplay}</strong>
          </div>
        </div>

        <div style={{ padding: '12px 14px', borderRadius: 8, backgroundColor: 'var(--canvas)', border: '1px solid var(--border)', color: 'var(--text-muted)', fontSize: '0.82rem', lineHeight: 1.5, marginBottom: 24, display: 'flex', gap: 10 }}>
          <Info size={18} />
          <div><strong>Lưu ý:</strong> Đây là thanh toán mô phỏng, không yêu cầu thông tin thẻ thật.</div>
        </div>

        {!isTerminal && (
          <div style={{ display: 'flex', gap: 12, flexWrap: 'wrap' }}>
            <button type='button' onClick={handleConfirm} disabled={isSubmitting} className='ef-btn ef-btn-primary' style={{ flex: '1 1 240px', padding: 13 }}>
              <CheckCircle2 size={18} /> {isSubmitting ? 'Đang xử lý...' : 'Xác nhận đặt vé'}
            </button>
            <button type='button' onClick={() => setShowCancelDialog(true)} disabled={isSubmitting} className='ef-btn ef-btn-secondary' style={{ flex: '1 1 140px', padding: 13 }}>
              Hủy giữ vé
            </button>
          </div>
        )}

        {isAlreadyConfirmed && (
          <Link href='/my-tickets' className='ef-btn ef-btn-primary'>
            Xem vé của tôi
          </Link>
        )}
      </div>

      <ConfirmDialog
        isOpen={showCancelDialog}
        title='Hủy giữ vé này?'
        message='Chỗ sẽ được trả lại kho sự kiện và có thể được cấp cho người đang chờ.'
        confirmText='Hủy giữ vé'
        cancelText='Tiếp tục giữ'
        isDestructive
        onConfirm={handleCancel}
        onCancel={() => setShowCancelDialog(false)}
      />
    </div>
  );
};

export default CheckoutPage;
