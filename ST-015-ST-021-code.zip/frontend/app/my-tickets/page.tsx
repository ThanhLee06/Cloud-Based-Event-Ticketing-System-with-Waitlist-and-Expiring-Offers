'use client';

import React, { useEffect, useState } from 'react';
import Link from 'next/link';
import { useAuth, loginRedirectPath } from '@lib/auth/AuthProvider';
import {
  cancelReservation,
  getMyReservations,
  type Reservation,
} from '@lib/api/reservations';
import { getApiErrorMessage } from '@lib/api/client';
import { formatVND, formatDateVN } from '@lib/utils/format';
import Countdown from '@components/Countdown/Countdown';
import ConfirmDialog from '@components/Modal/ConfirmDialog';
import { Calendar, MapPin, CheckCircle2, Clock, XCircle, History, ShieldCheck, ArrowRight, Compass } from 'lucide-react';

type TicketTab = 'CONFIRMED' | 'HOLD' | 'HISTORY';

const MyTicketsPage: React.FC = () => {
  const { status, loggedOutByUser } = useAuth();
  const [reservations, setReservations] = useState<Reservation[]>([]);
  const [activeTab, setActiveTab] = useState<TicketTab>('CONFIRMED');
  const [selected, setSelected] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [message, setMessage] = useState<string | null>(null);
  const [now, setNow] = useState(Date.now());

  const load = async () => {
    try {
      setMessage(null);
      setReservations(await getMyReservations());
    } catch (err) {
      setMessage(getApiErrorMessage(err, 'Không thể tải vé của bạn.'));
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (status === 'loading') return;
    if (status === 'anonymous') {
      window.location.href = loginRedirectPath('/my-tickets', loggedOutByUser);
      return;
    }
    void load();
  }, [status, loggedOutByUser]);

  useEffect(() => {
    const timer = window.setInterval(() => setNow(Date.now()), 1000);
    return () => window.clearInterval(timer);
  }, []);

  if (status === 'loading' || loading) return <div className='ef-loading'>Đang tải vé...</div>;

  const confirmed = reservations.filter((r) => r.status === 'CONFIRMED');
  const holds = reservations.filter((r) => r.status === 'HOLD' && new Date(r.expiresAt).getTime() > now);
  const history = reservations.filter(
    (r) =>
      r.status === 'CANCELLED' ||
      r.status === 'EXPIRED' ||
      (r.status === 'HOLD' && new Date(r.expiresAt).getTime() <= now),
  );
  const list = activeTab === 'CONFIRMED' ? confirmed : activeTab === 'HOLD' ? holds : history;

  const doCancel = async () => {
    if (!selected) return;
    try {
      const result = await cancelReservation(selected);
      setReservations((old) => old.map((r) => (r.id === selected ? result.reservation : r)));
      setMessage('Đã hủy vé/giữ chỗ thành công.');
    } catch (err) {
      setMessage(getApiErrorMessage(err, 'Không thể hủy vé.'));
    } finally {
      setSelected(null);
    }
  };

  const tabs = [
    { id: 'CONFIRMED' as const, label: 'Vé đã xác nhận', count: confirmed.length, Icon: ShieldCheck },
    { id: 'HOLD' as const, label: 'Đang giữ chỗ', count: holds.length, Icon: Clock },
    { id: 'HISTORY' as const, label: 'Lịch sử', count: history.length, Icon: History },
  ];

  return (
    <div className='ef-container-md'>
      <div style={{ marginBottom: 28 }}>
        <h1 style={{ fontSize: '1.75rem', fontWeight: 700, marginBottom: 6 }}>Vé của tôi</h1>
        <p style={{ color: 'var(--text-muted)', fontSize: '0.92rem' }}>
          Dữ liệu được lấy trực tiếp từ Backend Reservations API.
        </p>
      </div>

      {message && (
        <div className='ef-badge-neutral' style={{ padding: 12, borderRadius: 8, marginBottom: 20 }}>
          {message}
        </div>
      )}

      <div role='tablist' style={{ display: 'flex', gap: 6, borderBottom: '1px solid var(--border)', marginBottom: 24, flexWrap: 'wrap' }}>
        {tabs.map(({ id, label, count, Icon }) => (
          <button
            key={id}
            type='button'
            role='tab'
            aria-selected={activeTab === id}
            onClick={() => setActiveTab(id)}
            style={{
              display: 'inline-flex',
              alignItems: 'center',
              gap: 8,
              padding: '10px 16px',
              borderBottom: activeTab === id ? '2px solid var(--action)' : '2px solid transparent',
              color: activeTab === id ? 'var(--text)' : 'var(--text-muted)',
              fontWeight: activeTab === id ? 700 : 500,
            }}
          >
            <Icon size={16} /> {label} ({count})
          </button>
        ))}
      </div>

      {list.length ? (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
          {list.map((res) => {
            const event = res.event;
            if (!event) return null;
            const isHold = res.status === 'HOLD' && new Date(res.expiresAt).getTime() > now;
            const isConfirmed = res.status === 'CONFIRMED';
            return (
              <div key={res.id} className='ef-card' style={{ padding: 20, display: 'flex', gap: 20, alignItems: 'center', flexWrap: 'wrap' }}>
                <img src={event.poster} alt={event.title} style={{ width: 100, height: 100, borderRadius: 8, objectFit: 'cover' }} />
                <div style={{ flex: '1 1 240px' }}>
                  <div style={{ display: 'flex', gap: 8, marginBottom: 4, alignItems: 'center' }}>
                    <span style={{ fontSize: '0.74rem', fontWeight: 600, color: 'var(--text-muted)' }}>{event.category}</span>
                    <span className={`ef-badge ${isConfirmed ? 'ef-badge-success' : isHold ? 'ef-badge-warning' : 'ef-badge-neutral'}`} style={{ padding: '2px 8px', fontSize: '0.72rem' }}>
                      {isConfirmed ? 'Vé hợp lệ' : isHold ? 'Đang giữ chỗ' : res.status === 'CANCELLED' ? 'Đã hủy' : 'Đã hết hạn'}
                    </span>
                  </div>
                  <h2 style={{ fontSize: '1.05rem', fontWeight: 700, marginBottom: 6 }}>{event.title}</h2>
                  <div style={{ display: 'flex', flexDirection: 'column', gap: 4, fontSize: '0.8rem', color: 'var(--text-muted)', marginBottom: 10 }}>
                    <span><Calendar size={13} style={{ verticalAlign: 'middle' }} /> {formatDateVN(event.startsAt)}</span>
                    <span><MapPin size={13} style={{ verticalAlign: 'middle' }} /> {event.venue}, {event.city}</span>
                  </div>
                  <div style={{ display: 'flex', gap: 16, flexWrap: 'wrap', fontSize: '0.8rem', color: 'var(--text-muted)' }}>
                    {res.ticketCode && <span>Mã vé: <strong style={{ color: 'var(--text)' }}>{res.ticketCode}</strong></span>}
                    <span>Giá: <strong style={{ color: 'var(--text)' }}>{res.priceVnd === 0 ? 'Miễn phí' : formatVND(res.priceVnd)}</strong></span>
                  </div>
                </div>

                <div style={{ minWidth: 180, display: 'flex', flexDirection: 'column', gap: 8 }}>
                  {isHold && (
                    <>
                      <Countdown expiresAt={res.expiresAt} compact />
                      <Link href={`/checkout/${res.id}`} className='ef-btn ef-btn-primary ef-btn-full'>
                        Tiếp tục xác nhận <ArrowRight size={15} />
                      </Link>
                    </>
                  )}
                  {isConfirmed && (
                    <>
                      <Link href={`/events/${event.slug}`} className='ef-btn ef-btn-secondary'>Xem sự kiện</Link>
                      <button type='button' onClick={() => setSelected(res.id)} className='ef-btn ef-btn-danger'>
                        <XCircle size={14} /> Hủy vé
                      </button>
                    </>
                  )}
                  {!isHold && !isConfirmed && (
                    <Link href={`/events/${event.slug}`} className='ef-btn ef-btn-secondary'>Xem lại sự kiện</Link>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      ) : (
        <div className='ef-card' style={{ padding: '60px 20px', textAlign: 'center' }}>
          <div style={{ fontSize: '1.05rem', fontWeight: 600, marginBottom: 6 }}>Chưa có dữ liệu</div>
          <p style={{ color: 'var(--text-muted)', marginBottom: 20 }}>Khám phá các sự kiện đang mở bán để đặt vé.</p>
          <Link href='/' className='ef-btn ef-btn-primary'><Compass size={16} /> Khám phá sự kiện</Link>
        </div>
      )}

      <ConfirmDialog
        isOpen={Boolean(selected)}
        title='Hủy vé/giữ chỗ?'
        message='Chỗ sẽ được giải phóng để cấp cho người khác.'
        confirmText='Xác nhận hủy'
        cancelText='Giữ lại'
        isDestructive
        onConfirm={doCancel}
        onCancel={() => setSelected(null)}
      />
    </div>
  );
};

export default MyTicketsPage;
